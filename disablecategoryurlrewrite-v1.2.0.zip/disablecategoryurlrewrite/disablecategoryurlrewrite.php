<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class DisableCategoryUrlRewrite extends Module
{
    const LOG_FILE = _PS_ROOT_DIR_ . '/var/logs/disable_category_url_rewrite.log';

    public function __construct()
    {
        $this->name = 'disablecategoryurlrewrite';
        $this->tab = 'administration';
        $this->version = '1.2.0';
        $this->author = 'Thierry Laval';
        $this->need_instance = 0;
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('Désactive la mise à jour automatique des URLs');
        $this->description = $this->l('Empêche la modification automatique du slug (link_rewrite) des catégories et produits lors du changement de leur nom.');
        $this->confirmUninstall = $this->l('Etes-vous sûr de vouloir désinstaller ce module ?');
    }

    public function install()
    {
        return parent::install()
            && $this->registerHook('actionCategoryUpdate')
            && $this->registerHook('actionProductUpdate')
            && Configuration::updateValue('DISABLE_CAT_URL_REWRITE_ACTIVE', 0)
            && Configuration::updateValue('DISABLE_PROD_URL_REWRITE_ACTIVE', 0)
            && Configuration::updateValue('DISABLE_CAT_URL_REWRITE_LOG', 0)
            && Configuration::updateValue('DISABLE_CAT_URL_REWRITE_NOTIFY', 0);
    }

    public function uninstall()
    {
        return parent::uninstall()
            && Configuration::deleteByName('DISABLE_CAT_URL_REWRITE_ACTIVE')
            && Configuration::deleteByName('DISABLE_PROD_URL_REWRITE_ACTIVE')
            && Configuration::deleteByName('DISABLE_CAT_URL_REWRITE_LOG')
            && Configuration::deleteByName('DISABLE_CAT_URL_REWRITE_NOTIFY');
    }

    public function getContent()
    {
        if (Tools::isSubmit('submitDisableCatUrlRewrite')) {
            Configuration::updateValue('DISABLE_CAT_URL_REWRITE_ACTIVE', (int)Tools::getValue('DISABLE_CAT_URL_REWRITE_ACTIVE'));
            Configuration::updateValue('DISABLE_PROD_URL_REWRITE_ACTIVE', (int)Tools::getValue('DISABLE_PROD_URL_REWRITE_ACTIVE'));
            Configuration::updateValue('DISABLE_CAT_URL_REWRITE_LOG', (int)Tools::getValue('DISABLE_CAT_URL_REWRITE_LOG'));

            $oldNotify = Configuration::get('DISABLE_CAT_URL_REWRITE_NOTIFY');
            $newNotify = (int)Tools::getValue('DISABLE_CAT_URL_REWRITE_NOTIFY');
            Configuration::updateValue('DISABLE_CAT_URL_REWRITE_NOTIFY', $newNotify);

            if (!$oldNotify && $newNotify) {
                $this->notifyInstall();
            }

            $this->context->controller->confirmations[] = $this->l('Configuration mise à jour.');
        }

        return $this->renderSupport() . $this->renderRGPDNotice() . $this->renderForm();
    }

    protected function renderForm()
    {
        $fields_form = [
            'form' => [
                'legend' => [
                    'title' => $this->l('Paramètres'),
                    'icon' => 'icon-cogs',
                ],
                'input' => [
                    [
                        'type' => 'switch',
                        'label' => $this->l('Activer le blocage pour les catégories'),
                        'name' => 'DISABLE_CAT_URL_REWRITE_ACTIVE',
                        'is_bool' => true,
                        'desc' => $this->l('Empêche que le slug (link_rewrite) de la catégorie soit modifié automatiquement lors d’un changement de nom.'),
                        'values' => [
                            ['id' => 'active_on', 'value' => 1, 'label' => $this->l('Oui')],
                            ['id' => 'active_off', 'value' => 0, 'label' => $this->l('Non')],
                        ],
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->l('Activer le blocage pour les produits'),
                        'name' => 'DISABLE_PROD_URL_REWRITE_ACTIVE',
                        'is_bool' => true,
                        'desc' => $this->l('Empêche que le slug (link_rewrite) du produit soit modifié automatiquement lors d’un changement de nom.'),
                        'values' => [
                            ['id' => 'active_on', 'value' => 1, 'label' => $this->l('Oui')],
                            ['id' => 'active_off', 'value' => 0, 'label' => $this->l('Non')],
                        ],
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->l('Activer le mode debug / log'),
                        'name' => 'DISABLE_CAT_URL_REWRITE_LOG',
                        'is_bool' => true,
                        'desc' => $this->l('Journalise les actions dans le fichier de log.'),
                        'values' => [
                            ['id' => 'active_on', 'value' => 1, 'label' => $this->l('Oui')],
                            ['id' => 'active_off', 'value' => 0, 'label' => $this->l('Non')],
                        ],
                    ],
                    [
                        'type' => 'switch',
                        'label' => $this->l('Notifier par email à l’installation'),
                        'name' => 'DISABLE_CAT_URL_REWRITE_NOTIFY',
                        'is_bool' => true,
                        'desc' => $this->l('Envoie un email à l’auteur lors de l’installation du module (après activation explicite de cette option).'),
                        'values' => [
                            ['id' => 'active_on', 'value' => 1, 'label' => $this->l('Oui')],
                            ['id' => 'active_off', 'value' => 0, 'label' => $this->l('Non')],
                        ],
                    ],
                ],
                'submit' => [
                    'title' => $this->l('Sauvegarder'),
                    'class' => 'btn btn-default pull-right',
                ],
            ],
        ];

        $helper = new HelperForm();
        $helper->show_cancel_button = false;
        $helper->submit_action = 'submitDisableCatUrlRewrite';
        $helper->currentIndex = AdminController::$currentIndex . '&configure=' . $this->name;
        $helper->token = Tools::getAdminTokenLite('AdminModules');

        $helper->fields_value['DISABLE_CAT_URL_REWRITE_ACTIVE'] = Configuration::get('DISABLE_CAT_URL_REWRITE_ACTIVE');
        $helper->fields_value['DISABLE_PROD_URL_REWRITE_ACTIVE'] = Configuration::get('DISABLE_PROD_URL_REWRITE_ACTIVE');
        $helper->fields_value['DISABLE_CAT_URL_REWRITE_LOG'] = Configuration::get('DISABLE_CAT_URL_REWRITE_LOG');
        $helper->fields_value['DISABLE_CAT_URL_REWRITE_NOTIFY'] = Configuration::get('DISABLE_CAT_URL_REWRITE_NOTIFY');

        return $helper->generateForm([$fields_form]);
    }

    public function hookActionCategoryUpdate($params)
    {
        if (!Configuration::get('DISABLE_CAT_URL_REWRITE_ACTIVE')) {
            return;
        }

        if (!isset($params['category']) || !Validate::isLoadedObject($params['category'])) {
            return;
        }

        $category = $params['category'];
        $id_category = (int)$category->id;

        $sql = 'SELECT id_lang, link_rewrite FROM ' . _DB_PREFIX_ . 'category_lang WHERE id_category = ' . $id_category;
        $results = Db::getInstance()->executeS($sql);

        if (!$results) {
            $this->_log('Aucun link_rewrite trouvé pour la catégorie ID ' . $id_category);
            return;
        }

        foreach ($results as $row) {
            $id_lang = (int)$row['id_lang'];
            $old_link_rewrite = $row['link_rewrite'];
            $current_link_rewrite = isset($category->link_rewrite[$id_lang]) ? $category->link_rewrite[$id_lang] : '';

            if ($current_link_rewrite !== $old_link_rewrite) {
                $update = ['link_rewrite' => pSQL($old_link_rewrite)];
                $where = 'id_category = ' . $id_category . ' AND id_lang = ' . $id_lang;
                if (Db::getInstance()->update('category_lang', $update, $where)) {
                    $this->_log("Blocage slug catégorie ID $id_category (lang $id_lang) remis à '$old_link_rewrite'");
                }
            }
        }
    }

    public function hookActionProductUpdate($params)
    {
        if (!Configuration::get('DISABLE_PROD_URL_REWRITE_ACTIVE')) {
            return;
        }

        if (!isset($params['product']) || !Validate::isLoadedObject($params['product'])) {
            return;
        }

        $product = $params['product'];
        $id_product = (int)$product->id;

        $sql = 'SELECT id_lang, link_rewrite FROM ' . _DB_PREFIX_ . 'product_lang WHERE id_product = ' . $id_product;
        $results = Db::getInstance()->executeS($sql);

        if (!$results) {
            $this->_log('Aucun link_rewrite trouvé pour le produit ID ' . $id_product);
            return;
        }

        foreach ($results as $row) {
            $id_lang = (int)$row['id_lang'];
            $old_link_rewrite = $row['link_rewrite'];
            $current_link_rewrite = isset($product->link_rewrite[$id_lang]) ? $product->link_rewrite[$id_lang] : '';

            if ($current_link_rewrite !== $old_link_rewrite) {
                $update = ['link_rewrite' => pSQL($old_link_rewrite)];
                $where = 'id_product = ' . $id_product . ' AND id_lang = ' . $id_lang;
                if (Db::getInstance()->update('product_lang', $update, $where)) {
                    $this->_log("Blocage slug produit ID $id_product (lang $id_lang) remis à '$old_link_rewrite'");
                }
            }
        }
    }

    protected function _log($message)
    {
        if (!Configuration::get('DISABLE_CAT_URL_REWRITE_LOG')) return;
        $date = date('Y-m-d H:i:s');
        $text = "[$date] $message\n";
        @file_put_contents(self::LOG_FILE, $text, FILE_APPEND);
    }

    protected function renderSupport()
    {
        $html = '<fieldset><legend>' . $this->l('Support & Récompenses') . '</legend>';
        $html .= '<p><strong>Thierry Laval</strong><br/>';
        $html .= 'Site : <a href="https://thierrylaval.dev" target="_blank">thierrylaval.dev</a></p>';
        $html .= '<p><strong>' . $this->l("Votre don est précieux pour m’encourager à continuer de vous offrir des outils de qualité. Merci infiniment !") . '</strong></p>';
        $html .= '<p><a href="https://urlr.me/!paypalme-thierry" class="btn" target="_blank" title="' . $this->l('Faites un don via PayPal pour soutenir le développement') . '" style="background-color:#012990;color:#fff;padding:10px 15px;border-radius:5px;margin-right:10px;text-decoration:none;">Don via PayPal</a> ';
        $html .= '<a href="https://urlr.me/!revolut-thierry" class="btn" target="_blank" title="' . $this->l('Faites un don via Revolut pour soutenir le développement') . '" style="background-color:#7F47DD;color:#fff;padding:10px 15px;border-radius:5px;text-decoration:none;">Don via Revolut</a></p>';
        $html .= '</fieldset>';
        return $html;
    }

    protected function renderRGPDNotice()
    {
        $html = '<fieldset><legend>' . $this->l('Conformité RGPD') . '</legend>';
        $html .= '<p style="font-size: 1em; color: #ff0000;">';
        $html .= $this->l("Ce module inclut une fonctionnalité optionnelle permettant d'informer son auteur lors de l'installation. Cette notification contient les données suivantes :") . '<br>';
        $html .= '<ul><li>' . $this->l('Nom de la boutique + URL de la boutique + Adresse email du marchand + Adresse IP du serveur.') . '</li></ul>';
        $html .= $this->l("Conformément au RGPD, cette collecte est facultative et ne sera déclenchée que si vous y consentez explicitement en cochant l'option dédiée dans les paramètres du module.") . "<br>";
        $html .= $this->l("Aucune donnée n'est stockée ni partagée. Cela permet à l'auteur du module de vous assister plus facilement en cas de problème.");



        $html .= '</p></fieldset>';
        return $html;
    }

    private function notifyInstall()
    {
        if (!Configuration::get('DISABLE_CAT_URL_REWRITE_NOTIFY')) return;

        $to = 'contact@thierrylaval.dev'; // Remplace ici par ton email
        $subject = '[PrestaShop] Installation du module ' . $this->name;
        $message = "Module: {$this->name}\n";
        $message .= 'Domaine: ' . Tools::getShopDomain() . "\n";
        $message .= 'Nom boutique: ' . Configuration::get('PS_SHOP_NAME') . "\n";
        $message .= 'Email admin: ' . Configuration::get('PS_SHOP_EMAIL') . "\n";
        $message .= 'IP serveur: ' . $_SERVER['SERVER_ADDR'] . "\n";

        @mail($to, $subject, $message);
    }
}
